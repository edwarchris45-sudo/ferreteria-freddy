-- FERRETERÍA FREDDY · Base de datos segura (Supabase)
-- 1) CAMBIA 'TU_CORREO@ejemplo.com' (solo en la línea marcada con ★) por tu correo: serás el DUEÑO.
-- 2) Pega todo en SQL Editor y pulsa Run. Se puede ejecutar más de una vez sin romper nada.

create table if not exists settings(id int primary key default 1 check (id=1), n1 text default 'FERRETERÍA', n2 text default 'FREDDY', ht text default 'Todo para tu obra y tu hogar', hs text default 'Calidad, buenos precios y atención de confianza.', wa text default '', ct text default '', cb text default '#2958a8', cy text default '#f8dc08', cn text default '#101c34', logo text default '');
insert into settings(id) values (1) on conflict (id) do nothing;
create table if not exists categories(id uuid primary key default gen_random_uuid(), name text not null, emoji text default '🛠', ord int default 0);
create table if not exists products(id uuid primary key default gen_random_uuid(), name text not null, price text default 'Consultar', old_price text default '', cat uuid references categories(id) on delete set null, offer boolean default false, thumb text default '', full text default '', created_at timestamptz default now());
create table if not exists ads(id uuid primary key default gen_random_uuid(), title text not null, body text default '', link text default '', img text default '', created_at timestamptz default now());
alter table categories add column if not exists img text default '';
alter table ads add column if not exists video text default '';
alter table ads add column if not exists kind text default 'marca';
alter table ads add column if not exists own boolean default false;
create table if not exists suggestions(id uuid primary key default gen_random_uuid(), product text not null check (char_length(product) between 1 and 200), details text default '' check (char_length(details)<=1000), customer text default '' check (char_length(customer)<=200), done boolean default false, created_at timestamptz default now());
create table if not exists admins(email text primary key check (email = lower(email)), role text not null default 'editor' check (role in ('owner','editor')));

-- ★ AQUÍ va tu correo (dueño)
insert into admins(email,role) values (lower('TU_CORREO@ejemplo.com'),'owner') on conflict (email) do update set role='owner';

-- Secciones iniciales (solo si aún no hay ninguna)
insert into categories(name,emoji,ord)
select * from (values ('Plomería','🚰',0),('Cerámica y baño','🛁',1),('Pintura','🎨',2),('Electricidad','💡',3),('Mantenimiento de piscina','🏊',4),('Tornillos y fijaciones','🔩',5)) v(name,emoji,ord)
where not exists (select 1 from categories);

create or replace function is_admin() returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from admins where email = lower(auth.jwt()->>'email')) $$;
create or replace function is_owner() returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from admins where email = lower(auth.jwt()->>'email') and role='owner') $$;
-- Freno anti-spam: máximo 60 sugerencias por hora en total
create or replace function sug_ok() returns boolean language sql security definer stable set search_path=public as $$ select (select count(*) from suggestions where created_at > now() - interval '1 hour') < 60 $$;

alter table settings enable row level security; alter table categories enable row level security; alter table products enable row level security;
alter table ads enable row level security; alter table suggestions enable row level security; alter table admins enable row level security;

-- Todo el mundo LEE el catálogo; solo administradores ESCRIBEN
drop policy if exists "leer" on settings;   drop policy if exists "admin" on settings;
drop policy if exists "leer" on categories; drop policy if exists "admin" on categories;
drop policy if exists "leer" on products;   drop policy if exists "admin" on products;
drop policy if exists "leer" on ads;        drop policy if exists "admin" on ads;
drop policy if exists "enviar" on suggestions; drop policy if exists "admin" on suggestions;
drop policy if exists "ver" on admins;      drop policy if exists "dueno" on admins;

create policy "leer" on settings for select using (true);   create policy "admin" on settings for all using (is_admin()) with check (is_admin());
create policy "leer" on categories for select using (true); create policy "admin" on categories for all using (is_admin()) with check (is_admin());
create policy "leer" on products for select using (true);   create policy "admin" on products for all using (is_admin()) with check (is_admin());
create policy "leer" on ads for select using (true);        create policy "admin" on ads for all using (is_admin()) with check (is_admin());
-- Cualquiera puede ENVIAR una sugerencia (con freno anti-spam); solo administradores la ven y gestionan
create policy "enviar" on suggestions for insert to anon, authenticated with check (sug_ok());
create policy "admin" on suggestions for all using (is_admin()) with check (is_admin());
-- Solo el dueño gestiona el equipo
create policy "ver" on admins for select using (is_admin()); create policy "dueno" on admins for all using (is_owner()) with check (is_owner());

-- Fotos: carpeta pública para ver, solo administradores suben/borran. Solo imágenes, máx. 50 MB.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('media','media',true,52428800,array['image/jpeg','image/png','image/webp','image/gif','image/heic','image/heif','image/avif','video/mp4','video/webm','video/quicktime'])
on conflict (id) do update set public=true, file_size_limit=52428800, allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif','image/heic','image/heif','image/avif','video/mp4','video/webm','video/quicktime'];
drop policy if exists "subir" on storage.objects; drop policy if exists "cambiar" on storage.objects; drop policy if exists "borrar" on storage.objects;
create policy "subir" on storage.objects for insert with check (bucket_id='media' and is_admin());
create policy "cambiar" on storage.objects for update using (bucket_id='media' and is_admin());
create policy "borrar" on storage.objects for delete using (bucket_id='media' and is_admin());

-- Noticias (blog), Nosotros/Sucursales y boletín
alter table settings add column if not exists about text default '';
alter table settings add column if not exists branches text default '';
create table if not exists posts(id uuid primary key default gen_random_uuid(), title text not null check (char_length(title)<=200), body text default '', img text default '', created_at timestamptz default now());
create table if not exists subscribers(id uuid primary key default gen_random_uuid(), email text not null unique check (char_length(email) between 5 and 200 and email ~* '^\S+@\S+\.\S+$'), created_at timestamptz default now());
alter table posts enable row level security; alter table subscribers enable row level security;
drop policy if exists "leer" on posts; drop policy if exists "admin" on posts; drop policy if exists "suscribir" on subscribers; drop policy if exists "admin" on subscribers;
create policy "leer" on posts for select using (true);
create policy "admin" on posts for all using (is_admin()) with check (is_admin());
create policy "suscribir" on subscribers for insert to anon, authenticated with check (true);
create policy "admin" on subscribers for all using (is_admin()) with check (is_admin());
