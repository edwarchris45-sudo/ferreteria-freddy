# Ferretería Freddy · Guía de instalación (≈ 30 min)

Tendrás: tu página en **tu dominio**, con candado HTTPS, base de datos propia, fotos en alta calidad, varios administradores y sugerencias de clientes guardadas.

## 1. Base de datos (Supabase, plan gratuito)
1. Crea cuenta en supabase.com → **New project** (guarda la contraseña de la base de datos).
2. Menú **SQL Editor** → abre `setup.sql`, cambia `TU_CORREO@ejemplo.com` por tu correo (hay una sola línea marcada con ★), pega todo y pulsa **Run**. Si lo ejecutas dos veces no pasa nada.
3. Menú **Project Settings → API**: copia **Project URL** y la clave **anon public**.
   Pégalas en `config.js`. ⚠️ Nunca uses la clave `service_role`.

## 2. Tu cuenta de dueño
1. Menú **Authentication → Providers → Email**: deja activado **Confirm email**.
2. Abre la página → pie de página → **Acceso administrador** → **Crear cuenta** con el MISMO correo del paso 1.
3. Confirma el correo que te llega y entra. Verás el botón **⚙ Administrar**.

## 3. Publicar la página (hosting gratis con HTTPS)
Opción fácil: **Cloudflare Pages** o **Netlify** → "subir carpeta" (drag & drop) con `index.html`, `config.js` y `_headers` (este último añade seguridad extra; si no lo necesitas, puedes omitirlo).
Cada vez que cambies `config.js` o `index.html`, vuelve a subir la carpeta. Productos, fotos y ofertas NO requieren resubir: se editan desde ⚙ Administrar.

## 4. Tu dominio
1. Compra el dominio (Namecheap, GoDaddy, Cloudflare, etc.). Costo aproximado: 10–15 USD al año (verifica el precio vigente).
2. En el hosting: **Custom domain** → agrega tu dominio y copia los registros DNS que te indique.
3. Pégalos en el panel DNS de donde compraste el dominio. Tarda de minutos a unas horas.
4. En Supabase → **Authentication → URL Configuration**: pon tu dominio como **Site URL**.

## 5. Empleados
⚙ Administrar → **Equipo** → escribe el correo → **Dar acceso**. El empleado entra con «Crear cuenta». Puedes quitarle el acceso cuando quieras. Solo tú (dueño) ves esta sección.

## Probar antes de configurar
Si abres `index.html` con `config.js` sin rellenar, verás la tienda en **modo demostración** con productos de ejemplo (sin base de datos).

## Si olvidas tu contraseña
En «Acceso administrador» escribe tu correo y pulsa **Olvidé mi contraseña**. El enlace del correo te lleva a la página, donde aparece un cuadro para elegir la nueva contraseña (requiere el paso 4.4: Site URL).

## Seguridad: lista mínima
- Contraseña de mínimo 8 caracteres, larga y única; activa verificación en 2 pasos en tu correo, Supabase, hosting y dominio.
- Mantén "Confirm email" activado.
- Las reglas (RLS) ya impiden que un visitante cambie datos: solo correos autorizados.
- Descarga copias de tus tablas (Table Editor → Export CSV) cada cierto tiempo. Revisa si tu plan de Supabase incluye respaldos automáticos.
- En el plan gratuito, Supabase puede pausar el proyecto tras días sin visitas; se reactiva desde su panel.
- Costos y límites cambian: revísalos en supabase.com/pricing y en tu hosting.

## Fotos
Se guardan dos versiones: una liviana para la tienda (carga rápida) y otra grande que se abre al tocar la foto. En «Calidad de la foto» puedes elegir 1920 px, 2560 px u original (máx. 10 MB).


## Anuncios patrocinados con foto y video
En ⚙ Administrar → «Anuncios de proveedores» elige **Banner grande** (aparece bajo la portada) o **Marca** (franja azul oscura), y sube una foto y/o un video (máx. 50 MB, mejor .mp4). Si ya habías ejecutado `setup.sql`, vuelve a ejecutarlo para activar los videos.
