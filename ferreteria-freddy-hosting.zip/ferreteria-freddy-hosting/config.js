// Pega aquí los datos de tu proyecto de Supabase (Project Settings → API).
// Usa SOLO la clave "anon public". NUNCA pongas la "service_role".
window.CFG = {
  url: "https://TU-PROYECTO.supabase.co",
  key: "TU-CLAVE-ANON-PUBLICA"
};
